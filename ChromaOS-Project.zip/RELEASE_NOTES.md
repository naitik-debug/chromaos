# ChromaOS v2.0 — Android 10 to 16 Support & Warm Editorial Canvas

## 📥 Direct APK Download Link
> **[⬇️ Download ChromaOS-v2.0.apk (Direct APK Download)](../../releases/latest/download/ChromaOS-v2.0.apk)**
*(Once downloaded to your Android device, tap the file to install).*

---

## 🌟 What's New in Version 2.0

### 1. Rock-Solid Android 10 to 16 Compatibility
- Full native support for **Android 10 (Q), 11 (R), 12 (S), 13 (Tiramisu), 14 (UpsideDownCake), 15 (VanillaIceCream), and 16 (Baklava)**.
- Safe broadcast receiver registration using `RECEIVER_EXPORTED` flags for Android 14+.
- Graceful Bluetooth permission checks (`BLUETOOTH_CONNECT` runtime compatibility) preventing crashes on Android 12+.
- Modern edge-to-edge window insets handling camera cutouts and gesture navigation bars.

### 2. Clean-Slate Minimal Canvas (Zero Default Widgets)
- The home screen now launches with a **clean, serene canvas**—no pre-loaded widget clutter!
- **Long-Press on Empty Canvas**: Holding anywhere on the empty screen opens the **Tactile Widget Catalog Sheet**.
- **Pick & Place on Demand**:
  - 🔋 **Live Battery & Connected Devices Hub** (Real-time phone % + Bluetooth accessories)
  - 🕒 **Pixel At-A-Glance Clock** (Date & weather pill)
  - ⏳ **Android 17 Organic Split Clock**
  - 🔴 **Nothing OS Dot Matrix Clock**
  - ⚡ **POCO Turbo Speed Chrono**
  - 🎵 **Quick Audio & Adaptive Care Cards**
  - 🔍 **Home Search Bar Pill**
  - 📱 **Home App Grid**
  - ⚓ **Favorites Dock Bar**

### 3. Hold-to-Remove Widgets with Instant Undo
- **Press and hold (long-tap)** on any active widget or app icon to trigger a subtle haptic vibration and reveal the floating removal action.
- Tapping **Remove** clears the widget and immediately displays an **Undo Toast Banner** (`"Removed [Widget] • Tap to Undo"`).
- Tapping **Undo** instantly restores the widget back onto your home screen!

### 4. Human-Crafted Warm Editorial Theme ("Designed by Human, Not AI")
- **Obsidian Glass Materiality**: Multi-layer frosted glass (`rgba(14, 21, 18, 0.74)`) with physical specular highlights (`inset 0 1px 0 rgba(255, 255, 255, 0.16)`).
- **Muted Antique Bronze Accents**: Warm mineral tones (`#C8A97E`, `#8C6D53`, `#1B2621`) replacing artificial neon AI gradients.
- **Bespoke Editorial Typography**: Cormorant Garamond serif headings paired with clean Plus Jakarta Sans body and monospaced technical spec tags.
- **Physical Spring Feedback**: Smooth `cubic-bezier(0.16, 1, 0.3, 1)` transitions and tactile press-down micro-interactions (`active:scale-[0.97]`).

### 5. Real-Time Hardware Battery & Connected Devices Telemetry
- Native `ACTION_BATTERY_CHANGED` sticky receiver tracking real-time phone percentage, charging speeds (AC Fast, USB, Qi Wireless), temperature in °C, and battery health.
- Connected Bluetooth accessory discovery (wireless earbuds, smartwatches, styluses) showing battery levels right on your home screen.

---

## 📱 How to Install on Your Android Device
1. Tap the download link above to download **`ChromaOS-v2.0.apk`**.
2. If prompted by your browser or file manager, enable **"Allow from this source / Install unknown apps"**.
3. Tap **Install**.
4. Press your phone's Home button or swipe up to go home.
5. Select **ChromaOS** as your default launcher and tap **Always** (or change anytime in **Settings > Apps > Default apps > Home app**).
