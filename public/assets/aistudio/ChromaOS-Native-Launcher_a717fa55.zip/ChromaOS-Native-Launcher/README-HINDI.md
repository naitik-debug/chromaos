# ChromaOS Native Launcher — शुरुआती Android Studio प्रोजेक्ट

इस ZIP में तुम्हारी `ChromaOS-App (1).html` को `app/src/main/assets/chromaos/index.html` में रखा गया है और उसके साथ Kotlin-based Android launcher starter जोड़ा गया है।

## इसमें क्या है
- Android Home Launcher intent filter
- Installed launcher apps की सूची और ऐप खोलने की सुविधा
- Wallpaper picker और Android wallpaper apply
- 4 native color themes; चुना हुआ theme SharedPreferences में सेव होता है
- WebView में मौजूदा ChromaOS HTML Theme Studio
- HTML से editor-injected scripts हटाए गए हैं, जिनमें embedded Firebase auth token/editor messaging code था

## खोलने का तरीका
1. Android Studio install करो और खोलो।
2. `Open` चुनकर इस folder `ChromaOS-Native-Launcher` को खोलो।
3. Gradle sync पूरा होने दो; Android SDK 35 और JDK 17 की जरूरत होगी।
4. Emulator या USB debugging वाले Android फोन को चुनकर Run दबाओ।
5. Default launcher के लिए फोन की Settings → Apps → Default apps → Home app में ChromaOS चुनो (menu नाम फोन के अनुसार बदल सकता है)।

## जरूरी सीमाएँ
- यह एक starter implementation है; इस ZIP को यहां Android SDK के साथ compile/run करके verify नहीं किया गया है। Android Studio में Gradle sync/build और फोन पर परीक्षण जरूरी है।
- HTML के सभी theme controls अभी native launcher की settings से sync नहीं होते। फिलहाल native launcher में theme cycling अलग से है।
- HTML में external CDN resources हो सकते हैं; Theme Studio के कुछ fonts/icons/styles के लिए इंटरनेट की जरूरत पड़ सकती है। PWA install/service-worker behavior `file://` WebView में native feature की तरह काम नहीं करता।
- यह सामान्य Android launcher है, नया operating system नहीं। यह system notification shade, system lock screen, दूसरे launchers के icons या सभी system UI को नहीं बदल सकता।
- कोई Accessibility या overlay permission नहीं जोड़ी गई है।

## प्रोजेक्ट तकनीक
- Kotlin
- Android Gradle Plugin 8.9.2
- Kotlin Gradle Plugin 2.0.21
- compileSdk/targetSdk 35, minSdk 26
- Java/Kotlin target 17

## अगर Gradle sync fail हो
Android Studio के SDK Manager में Android SDK Platform 35 install करो और Gradle JDK को JDK 17 पर सेट करो। फिर `File → Sync Project with Gradle Files` और `Build → Make Project` चलाओ।
