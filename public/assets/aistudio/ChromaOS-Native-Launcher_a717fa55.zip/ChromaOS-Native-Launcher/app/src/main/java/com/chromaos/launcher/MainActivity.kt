package com.chromaos.launcher

import android.app.Activity
import android.app.WallpaperManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val wallpaperRequestCode = 1001
    private lateinit var root: LinearLayout
    private lateinit var appGrid: GridLayout
    private var paletteIndex = 0

    private val palettes = listOf(
        intArrayOf(Color.rgb(20, 24, 38), Color.rgb(139, 124, 255), Color.rgb(48, 54, 78)),
        intArrayOf(Color.rgb(25, 35, 31), Color.rgb(93, 204, 157), Color.rgb(39, 67, 57)),
        intArrayOf(Color.rgb(35, 25, 44), Color.rgb(255, 139, 180), Color.rgb(68, 45, 77)),
        intArrayOf(Color.rgb(35, 31, 25), Color.rgb(236, 174, 98), Color.rgb(73, 56, 41))
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        paletteIndex = getSharedPreferences("chromaos_settings", MODE_PRIVATE)
            .getInt("palette_index", 0).coerceIn(palettes.indices)
        buildHomeScreen()
        loadInstalledApps()
    }

    private fun buildHomeScreen() {
        val palette = palettes[paletteIndex]
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(28), dp(18), dp(12))
            setBackgroundColor(palette[0])
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val title = TextView(this).apply {
            text = "ChromaOS"
            textSize = 32f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Your Home. Your Style."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(14))
        }

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        actions.addView(actionButton("Wallpaper") { chooseWallpaper() }, weightedParams())
        actions.addView(actionButton("Change Theme") { cycleTheme() }, weightedParams())

        val studio = actionButton("Open ChromaOS Theme Studio") {
            startActivity(Intent(this@MainActivity, ThemeStudioActivity::class.java))
        }
        studio.setBackgroundColor(palette[1])

        val section = TextView(this).apply {
            text = "Installed Apps"
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            setPadding(0, dp(18), 0, dp(10))
        }

        appGrid = GridLayout(this).apply {
            columnCount = 3
            useDefaultMargins = false
        }

        content.addView(title)
        content.addView(subtitle)
        content.addView(actions)
        content.addView(studio)
        content.addView(section)
        content.addView(appGrid)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val footer = TextView(this).apply {
            text = "ChromaOS Launcher • Native preview"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(8), 0, dp(4))
        }
        root.addView(footer)
        setContentView(root)
    }

    private fun loadInstalledApps() {
        appGrid.removeAllViews()
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(launcherIntent, 0)
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }

        for (info in apps) {
            val cell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(10), dp(4), dp(10))
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    val launchIntent = packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)
                    if (launchIntent != null) {
                        try {
                            startActivity(launchIntent)
                        } catch (_: Exception) {
                            toast("This app could not be opened.")
                        }
                    } else {
                        toast("No launch screen found for this app.")
                    }
                }
            }
            val icon = ImageView(this).apply {
                setImageDrawable(info.loadIcon(packageManager))
                scaleType = ImageView.ScaleType.FIT_CENTER
                contentDescription = info.loadLabel(packageManager).toString()
                layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
            }
            val label = TextView(this).apply {
                text = info.loadLabel(packageManager).toString()
                textSize = 11f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                maxLines = 2
                setPadding(0, dp(5), 0, 0)
            }
            cell.addView(icon)
            cell.addView(label)
            val params = GridLayout.LayoutParams().apply {
                width = 0
                height = ViewGroup.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(2), dp(2), dp(2), dp(2))
            }
            appGrid.addView(cell, params)
        }
    }

    private fun chooseWallpaper() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        startActivityForResult(intent, wallpaperRequestCode)
    }

    @Deprecated("Kept for compatibility with the starter project; can be migrated to Activity Result APIs")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == wallpaperRequestCode && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            try {
                contentResolver.openInputStream(uri).use { stream ->
                    requireNotNull(stream) { "Selected image could not be read" }
                    WallpaperManager.getInstance(this).setStream(stream)
                }
                toast("Wallpaper updated!")
            } catch (_: Exception) {
                toast("Wallpaper could not be changed on this device.")
            }
        }
    }

    private fun cycleTheme() {
        paletteIndex = (paletteIndex + 1) % palettes.size
        getSharedPreferences("chromaos_settings", MODE_PRIVATE)
            .edit().putInt("palette_index", paletteIndex).apply()
        buildHomeScreen()
        loadInstalledApps()
        toast("Theme saved")
    }

    private fun actionButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 12f
        setOnClickListener { action() }
    }

    private fun weightedParams() = LinearLayout.LayoutParams(0, dp(48), 1f).apply {
        setMargins(dp(3), dp(4), dp(3), dp(4))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
