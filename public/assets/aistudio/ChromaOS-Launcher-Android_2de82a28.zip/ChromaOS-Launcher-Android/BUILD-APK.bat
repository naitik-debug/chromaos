@echo off
setlocal
cd /d "%~dp0"
if not exist "gradlew.bat" (
  echo First run PREPARE-WRAPPER.bat, then run this file again.
  pause
  exit /b 1
)
call gradlew.bat assembleDebug
if errorlevel 1 (
  echo Build failed. Open the project in Android Studio and check SDK / Gradle errors.
  pause
  exit /b 1
)
echo.
echo APK created at:
echo %~dp0app\build\outputs\apk\debug\app-debug.apk
pause
