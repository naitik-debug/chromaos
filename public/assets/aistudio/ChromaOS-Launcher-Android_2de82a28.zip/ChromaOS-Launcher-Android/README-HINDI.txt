ChromaOS Launcher — Android Studio Project
==========================================

Is ZIP mein aapki original ChromaOS HTML file ko Android app ke andar rakha gaya hai.
Native launcher mein:
- Installed launcher apps ki list aur search
- App icon par tap karke app kholna
- Wallpaper select karna
- Theme color ko local preferences mein save karna
- HTML Theme Studio kholna
- Android ke Default Home app ke roop mein select hone ka support

APK banane ke liye:
1. ZIP extract karein.
2. Android Studio install/open karein.
3. Android Studio mein "Open" par click karke extracted "ChromaOS-Launcher-Android" folder select karein.
4. Gradle Sync complete hone dein. Pehli baar internet chahiye ho sakta hai, kyunki Android Gradle Plugin aur SDK components download ho sakte hain.
5. JDK/Gradle JDK ko 17 par set karein (Android Studio ke bundled JDK 17/compatible JDK ka use karein).
6. SDK Manager mein Android SDK Platform 35 aur Build Tools install karein.
7. Build > Build Bundle(s) / APK(s) > Build APK(s) select karein.
8. Build complete hone par "Locate" par click karein. APK aam taur par:
   app/build/outputs/apk/debug/app-debug.apk
9. APK ko phone mein copy karke install karein. Phone par unknown-source install permission mangi ja sakti hai; sirf apne banaye/ bharosemand APK ko install karein.
10. Settings > Apps > Default apps > Home app mein ChromaOS Launcher select karein.

Important:
- Is environment mein Android SDK/Gradle maujood nahin tha, isliye prebuilt APK generate ya compile-test nahin kiya gaya.
- Yeh Android Studio mein build karne ke liye project ZIP hai, ready-made APK nahin.
- HTML mein kuch CDN assets hain; Theme Studio ko un assets ke liye internet ki zarurat ho sakti hai.
- Native launcher system notification shade, lock screen, ya doosre launchers ke icons ko poori tarah modify nahin karta.
- Debug APK personal testing ke liye hai. Public release se pehle signing, privacy aur compatibility test karein.

Optional Windows shortcuts:
- PREPARE-WRAPPER.bat: internet se Gradle download karke Gradle Wrapper files banata hai.
- BUILD-APK.bat: wrapper ready hone ke baad debug APK build karta hai.
- Build ke liye Android SDK Platform 35 aur JDK 17 chahiye. Agar SDK installed nahin hai, pehle Android Studio ke SDK Manager se install karein.
