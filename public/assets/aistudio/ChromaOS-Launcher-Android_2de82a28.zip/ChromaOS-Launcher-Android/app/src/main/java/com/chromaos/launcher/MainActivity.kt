package com.chromaos.launcher

import android.app.Activity
import android.app.WallpaperManager
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts

data class LauncherApp(
    val label: String,
    val packageName: String,
    val icon: android.graphics.drawable.Drawable
)

class MainActivity : Activity() {

    private lateinit var appGrid: GridLayout
    private lateinit var searchBox: EditText
    private lateinit var apps: List<LauncherApp>
    private lateinit var root: LinearLayout

    private val prefs by lazy {
        getSharedPreferences("chromaos_settings", MODE_PRIVATE)
    }

    private val wallpaperPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) applyWallpaper(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildHomeScreen()
        loadInstalledApps()

        searchBox.addTextChangedListener(SimpleTextWatcher {
            renderApps(it)
        })
    }

    private fun buildHomeScreen() {
        val savedColor = prefs.getInt("background_color", Color.rgb(20, 24, 38))

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(28), dp(18), dp(16))
            setBackgroundColor(savedColor)
        }

        val title = TextView(this).apply {
            text = "ChromaOS"
            textSize = 32f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        }

        val subtitle = TextView(this).apply {
            text = "Your Home. Your Style."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(2), 0, dp(14))
        }

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        actions.addView(actionButton("Wallpaper") { wallpaperPicker.launch(arrayOf("image/*")) })
        actions.addView(actionButton("Theme Studio") {
            startActivity(Intent(this@MainActivity, ThemeStudioActivity::class.java))
        })
        actions.addView(actionButton("Theme color") { cycleThemeColor() })

        searchBox = EditText(this).apply {
            hint = "Search apps..."
            textSize = 16f
            singleLine = true
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = roundedBackground(Color.argb(45, 255, 255, 255))
        }

        val appsTitle = TextView(this).apply {
            text = "Installed Apps"
            textSize = 20f
            setTextColor(Color.WHITE)
            setPadding(0, dp(18), 0, dp(8))
        }

        appGrid = GridLayout(this).apply {
            columnCount = 3
            alignmentMode = GridLayout.ALIGN_BOUNDS
            useDefaultMargins = false
        }

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(appGrid)
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(actions)
        root.addView(searchBox, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(48)
        ).apply { topMargin = dp(12) })
        root.addView(appsTitle)
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        setContentView(root)
    }

    private fun loadInstalledApps() {
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = packageManager.queryIntentActivities(launcherIntent, 0)
            .distinctBy { it.activityInfo.packageName }
            .map {
                LauncherApp(
                    label = it.loadLabel(packageManager).toString(),
                    packageName = it.activityInfo.packageName,
                    icon = it.loadIcon(packageManager)
                )
            }
            .sortedBy { it.label.lowercase() }

        renderApps(searchBox.text?.toString().orEmpty())
    }

    private fun renderApps(query: String) {
        if (!::appGrid.isInitialized || !::apps.isInitialized) return
        appGrid.removeAllViews()

        val filtered = apps.filter { it.label.contains(query.trim(), ignoreCase = true) }

        if (filtered.isEmpty()) {
            val empty = TextView(this).apply {
                text = "No apps found"
                setTextColor(Color.WHITE)
                textSize = 16f
                gravity = Gravity.CENTER
                setPadding(0, dp(24), 0, dp(24))
            }
            appGrid.addView(empty, GridLayout.LayoutParams().apply {
                width = ViewGroup.LayoutParams.MATCH_PARENT
                height = ViewGroup.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(0, 3)
            })
            return
        }

        filtered.forEach { app ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(10), dp(4), dp(10))
                isClickable = true
                isFocusable = true
                background = roundedBackground(Color.argb(18, 255, 255, 255))
                contentDescription = app.label
                setOnClickListener { launchApp(app.packageName) }
            }

            val icon = TextView(this).apply {
                text = ""
                gravity = Gravity.CENTER
                val drawable = app.icon
                drawable.setBounds(0, 0, dp(44), dp(44))
                setCompoundDrawables(null, drawable, null, null)
                setPadding(0, 0, 0, dp(5))
            }

            val label = TextView(this).apply {
                text = app.label
                textSize = 11f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
            }

            item.addView(icon)
            item.addView(label)
            val params = GridLayout.LayoutParams().apply {
                width = 0
                height = dp(94)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(3), dp(3), dp(3), dp(3))
            }
            appGrid.addView(item, params)
        }
    }

    private fun launchApp(packageName: String) {
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) {
            try {
                startActivity(intent)
            } catch (_: Exception) {
                Toast.makeText(this, "App could not be opened", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "This app cannot be opened from the launcher", Toast.LENGTH_SHORT).show()
        }
    }

    private fun applyWallpaper(uri: Uri) {
        try {
            contentResolver.openInputStream(uri).use { stream ->
                if (stream == null) throw IllegalStateException("Cannot read image")
                WallpaperManager.getInstance(this).setStream(stream)
            }
            Toast.makeText(this, "Wallpaper updated", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
            Toast.makeText(this, "Wallpaper could not be changed", Toast.LENGTH_LONG).show()
        }
    }

    private fun cycleThemeColor() {
        val colors = listOf(
            Color.rgb(20, 24, 38),
            Color.rgb(20, 40, 52),
            Color.rgb(42, 25, 56),
            Color.rgb(35, 35, 35),
            Color.rgb(26, 48, 38)
        )
        val current = prefs.getInt("background_color", colors[0])
        val next = colors[(colors.indexOf(current).coerceAtLeast(0) + 1) % colors.size]
        prefs.edit().putInt("background_color", next).apply()
        root.setBackgroundColor(next)
        Toast.makeText(this, "Theme color saved", Toast.LENGTH_SHORT).show()
    }

    private fun actionButton(label: String, action: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            textSize = 12f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(12), dp(10), dp(12))
            background = roundedBackground(Color.argb(48, 255, 255, 255))
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                .apply { setMargins(dp(3), 0, dp(3), 0) }
        }
    }

    private fun roundedBackground(color: Int): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(16).toFloat()
        }
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}

private class SimpleTextWatcher(
    private val onChanged: (String) -> Unit
) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
        onChanged(s?.toString().orEmpty())
    }
    override fun afterTextChanged(s: android.text.Editable?) = Unit
}
