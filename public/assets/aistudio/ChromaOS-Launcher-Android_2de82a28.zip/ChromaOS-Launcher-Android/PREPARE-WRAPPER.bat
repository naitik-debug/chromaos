@echo off
setlocal
cd /d "%~dp0"
set "GRADLE_VERSION=8.9"
set "GRADLE_HOME=%USERPROFILE%\.gradle\chromao-bootstrap\gradle-%GRADLE_VERSION%"
set "ZIP_FILE=%TEMP%\gradle-%GRADLE_VERSION%-bin.zip"

if exist "%GRADLE_HOME%\bin\gradle.bat" goto makewrapper

echo Downloading Gradle %GRADLE_VERSION%. Internet connection required...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP_FILE%'; New-Item -ItemType Directory -Force -Path '%USERPROFILE%\.gradle\chromao-bootstrap' | Out-Null; Expand-Archive -Path '%ZIP_FILE%' -DestinationPath '%USERPROFILE%\.gradle\chromao-bootstrap' -Force"
if errorlevel 1 (
  echo Download failed. Check your internet connection and run this file again.
  pause
  exit /b 1
)

:makewrapper
echo Creating Gradle Wrapper files...
"%GRADLE_HOME%\bin\gradle.bat" wrapper --gradle-version %GRADLE_VERSION% --distribution-type bin
if errorlevel 1 (
  echo Wrapper generation failed. Open the project in Android Studio and check Gradle sync.
  pause
  exit /b 1
)
echo Done. Now open this folder in Android Studio.
pause
